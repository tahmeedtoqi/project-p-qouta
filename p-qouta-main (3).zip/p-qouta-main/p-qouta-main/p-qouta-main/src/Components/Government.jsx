import Footer from "./Footer";
import Navbar from "./Navbar";


const Government = () => {
  return (
    <div>
      <Navbar></Navbar>
      <h2>government</h2>
      <Footer></Footer>
    </div>
  );
};

export default Government;