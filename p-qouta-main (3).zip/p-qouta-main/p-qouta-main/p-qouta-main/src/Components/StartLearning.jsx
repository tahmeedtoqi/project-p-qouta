

const StartLearning = () => {
  return (
    <div>
      <h2>learning</h2>
    </div>
  );
};

export default StartLearning;