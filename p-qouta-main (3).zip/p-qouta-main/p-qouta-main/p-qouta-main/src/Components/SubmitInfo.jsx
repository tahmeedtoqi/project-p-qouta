
const SubmitInfo = () => {
  return (
    <div>
       <h1 className="text-4xl font-bold text-center py-4">Quota Movement - 2024</h1>
      <iframe
        src="https://docs.google.com/forms/d/e/1FAIpQLSceBt-DhyZlTO51167z5lPnP50v1qFMNg03PpJI41VgnCsPnA/viewform"
        width="100%"
        height="600px"
        title="Google Form"
      />
    </div>
    
  );
};

export default SubmitInfo;